#include <gl/glut.h> 
#include <gl/gl.h> 
#include <gl/glu.h>

//MyDisplay�� �� 10���� primitive�� ���� �Լ��Դϴ�.
void MyDisplay1() {
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_POINTS);
	glVertex3f(-0.3, -0.25, 0.0);
	glVertex3f(-0.8, 0.25, 0.0);
	glVertex3f(-0.725, 0.4, 0.0);
	glVertex3f(-0.725, -0.625, 0.0);
	glVertex3f(0.1, 0.3, 0.0);
	glVertex3f(0.725, -0.4, 0.0);
	glEnd( );

	glFlush( );
}
void MyDisplay2() {

	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_LINE_LOOP);//start drawing a line loop
	glVertex3f(-1.0,0.0,0.0);//left of window
	glVertex3f(0.0,-0.5,0.0);//bottom of window
	glEnd();//end drawing of line loop

	glBegin(GL_LINE_LOOP);
	glVertex3f(0.5,0.0,0.0);//right of window
	glVertex3f(-0.05,0.2,0.0);//top of window
	glEnd();

	glBegin(GL_LINE_LOOP);
	glVertex3f(-0.5,0.0,0.0);//right of window
	glVertex3f(-0.05,0.7,0.0);//top of window
	glEnd();

	glFlush( );

}
void MyDisplay3(){
	glBegin(GL_LINE_STRIP);
	glVertex3f(-0.4, 0.0, 0);
	glVertex3f(-0.3, 0.2, 0);
	glVertex3f(-0.2, 0.0, 0);
	glVertex3f(-0.1, 0.2, 0);
	glVertex3f(0.0, 0.0, 0);
	glVertex3f(0.1, 0.2, 0);
	glVertex3f(0.2, 0.0, 0);
	glVertex3f(0.3, 0.2, 0);
	glVertex3f(-0.7, 0.0, 0);

	glEnd();
	glFlush( );
}
void MyDisplay4(){
	glBegin(GL_LINE_LOOP);
	glVertex3f(-0.4, 0.0, 0);
	glVertex3f(-0.5, 0.2, 0);
	glVertex3f(0.2, 0.5, 0);
	glVertex3f(-0.1, 0.2, 0);
	glVertex3f(0.0, 0.0, 0);
	glVertex3f(0.1, 0.2, 0);
	glVertex3f(0.2, 0.0, 0);
	glVertex3f(0.3, 0.2, 0);
	glVertex3f(-0.7, 0.0, 0);

	glEnd();
	glFlush( );
}
void MyDisplay5(){

	glBegin(GL_POLYGON);
	glVertex3f(-0.3,0.5,0.0);
	glVertex3f(0.4,0.4,0.0);
	glVertex3f(0.5,-0.3,0.0);
	glVertex3f(-0.4,-0.5,0.0);
	glVertex3f(-0.7,0.0,0.0);

	glEnd();
	glFlush();
}
void MyDisplay6(){

	glBegin(GL_QUADS);
	glVertex3f(-0.1,0.25,0.0);
	glVertex3f(0.13,0.2,0.0);
	glVertex3f(0.22,-0.15,0.0);
	glVertex3f(-0.2,-0.25,0.0);

	glVertex3f(0.4,0.75,0.0);
	glVertex3f(0.63,0.6,0.0);
	glVertex3f(0.52,0.3,0.0);
	glVertex3f(0.4,0.25,0.0);

	glEnd();
	glFlush();
}
void MyDisplay7(){
	glBegin(GL_QUAD_STRIP);
	glVertex3f(-0.5,0.25,0.0);
	glVertex3f(-0.2,0.2,0.0);
	glVertex3f(-0.6,-0.15,0.0);
	glVertex3f(-0.2,-0.25,0.0);
	glVertex3f(0.2,0.25,0.0);
	glVertex3f(0.4,0.25,0.0);

	glEnd();
	glFlush();
}
void MyDisplay8(){

	glBegin(GL_TRIANGLES);

	glVertex3f(0, 0, 0);
	glVertex3f(0.5, 0, 0);
	glVertex3f(0, 0.3, 0);
	glVertex3f(-0.3, 0.0, 0);
	glVertex3f(-0.4, -0.3,0);
	glVertex3f(-0.1, -0.2, 0);
	glEnd();
	glFlush();
}
void MyDisplay9(){
	glBegin(GL_TRIANGLE_STRIP);
	glVertex3f(0, 0, 0);
	glVertex3f(0.5, 0, 0);
	glVertex3f(0, 0.3, 0);
	glVertex3f(-0.3, 0.0, 0);
	glVertex3f(-0.4, 0.4,0);
	glVertex3f(-0.5, 0.3, 0);
	glEnd();
	glFlush();
}
void MyDisplay10(){
	glBegin(GL_TRIANGLE_FAN);
	glVertex3f(0, 0, 0);
	glVertex3f(0.5, 0, 0);
	glVertex3f(0.5, 0.2, 0);
	glVertex3f(0.3, 0.3, 0);
	glVertex3f(-0.1, 0.2,0);
	glVertex3f(-0.2, 0.1, 0);
	glEnd();
	glFlush();

}

//MynameDisplay�� ������ ���� �ְ����̶�� �̸��� �׸��ϴ�.
void MynameDisplay(){
	//���� ����մϴ�.
	glBegin(GL_POLYGON); //���� primitive�� ������ �˸��ϴ�.
	//���� glVertext3f�� ���� �� vertex���� ��ġ�� �����ݴϴ�.
	glVertex3f(-0.67, 0.28, 0);
	glVertex3f(-0.67, 0.33, 0);
	glVertex3f(-0.8, 0.33, 0);
	glVertex3f(-0.8, 0.28, 0);
	glVertex3f(-0.89, 0.28, 0);
	glVertex3f(-0.89, 0.23, 0);
	glVertex3f(-0.82, 0.23, 0);
	glVertex3f(-0.9, 0.05, 0);
	glVertex3f(-0.9, 0, 0);
	glVertex3f(-0.74, 0.2, 0);
	glVertex3f(-0.58, 0, 0);
	glVertex3f(-0.58, 0.05, 0);
	glVertex3f(-0.65, 0.23, 0);
	glVertex3f(-0.58, 0.23, 0);
	glVertex3f(-0.58, 0.28, 0);
	glEnd();//gl���Ḧ �˸��ϴ�

	glBegin(GL_POLYGON);//���� ����մϴ�.
	glVertex3f(-0.7, -0.1, 0);
	glVertex3f(-0.7, 0, 0);
	glVertex3f(-0.77, 0, 0);
	glVertex3f(-0.77, -0.1, 0);
	glVertex3f(-0.9, -0.1, 0);
	glVertex3f(-0.9, -0.15, 0);
	glVertex3f(-0.57, -0.15, 0);
	glVertex3f(-0.57, -0.1, 0);
	glEnd();

	glBegin(GL_QUADS); //l�� ����մϴ�.
	glVertex3f(-0.52, 0.34, 0);
	glVertex3f(-0.52, -0.17, 0);
	glVertex3f(-0.45, -0.17, 0);
	glVertex3f(-0.45, 0.34, 0);
	glEnd();

	
	//���� ����մϴ�.
	glBegin(GL_POLYGON);
	glVertex3f(0.03, 0.31, 0);
	glVertex3f(-0.23, 0.31, 0);
	glVertex3f(-0.23, 0.25, 0);
	glVertex3f(-0.09, 0.25, 0);
	glVertex3f(-0.23, 0.05, 0);
	glVertex3f(-0.2, 0, 0);
	glEnd();

	//���� ����մϴ�.
	glBegin(GL_POLYGON);
	glVertex3f(0.18, 0.2, 0);
	glVertex3f(0.18, 0.34, 0);
	glVertex3f(0.11, 0.34, 0);
	glVertex3f(0.11, 0, 0);
	glVertex3f(0.18, 0, 0);
	glVertex3f(0.18, 0.14, 0);
	glVertex3f(0.23, 0.14, 0);
	glVertex3f(0.23, 0.2, 0);
	glVertex3f(0.18, 0.19, 0);
	glEnd();

	//���� ����մϴ�.
	glBegin(GL_QUADS); 
	glVertex3f(0.1,0,0);
	glVertex3f(-0.1,0,0);
	glVertex3f(-0.18,-0.05,0);
	glVertex3f(0.18,-0.05,0);

	glVertex3f(0.1,-0.15,0);
	glVertex3f(-0.1,-0.15,0);
	glVertex3f(-0.18,-0.1,0);
	glVertex3f(0.18,-0.1,0);

	
	glVertex3f(-0.18,-0.05,0);
	glVertex3f(-0.18,-0.1,0);
	glVertex3f(-0.1,-0.1,0);
	glVertex3f(-0.1,-0.05,0);

	glVertex3f(0.18,-0.05,0);
	glVertex3f(0.18,-0.1,0);
	glVertex3f(0.1,-0.1,0);
	glVertex3f(0.1,-0.05,0);

	glEnd();
	

	//���� ����մϴ�.
	glBegin(GL_POLYGON);
	glVertex3f(0.55, 0.33, 0);
	glVertex3f(0.48, 0.33, 0);
	glVertex3f(0.35, 0.05, 0);
	glVertex3f(0.35, 0, 0);
	glVertex3f(0.51, 0.2, 0);
	glVertex3f(0.67, 0, 0);
	glVertex3f(0.67, 0.05, 0);
	glEnd();

	//���� ����մϴ�.
	glBegin(GL_POLYGON);

	glVertex3f(0.73, 0.15, 0);
	glVertex3f(0.73, 0, 0);
	glVertex3f(0.80, 0, 0);
	glVertex3f(0.80, 0.34, 0);
	glVertex3f(0.73, 0.34, 0);
	glVertex3f(0.73, 0.20, 0);
	glVertex3f(0.68, 0.20, 0);
	glVertex3f(0.68, 0.15, 0);
	
	glEnd();
	//���� ��� �մϴ�.
	glBegin(GL_QUAD_STRIP);
	glVertex3f(0.4, -0.04, 0);
	glVertex3f(0.4, -0.1, 0);
	glVertex3f(0.8, -0.04, 0);
	glVertex3f(0.72, -0.1, 0);
	glVertex3f(0.8, -0.2, 0);
	glVertex3f(0.72, -0.2, 0);
	
	glEnd();

	glFlush();
	//����̹��� ���ɾ ���� ���� �������
	//���� ���ɾ ��� ���μ����� �����ϵ��� ���ش�
}


int main( ) {
	glutCreateWindow("OpenGL Drawing Example");
	glutDisplayFunc(MynameDisplay);
	glutMainLoop( );

	return 0;
}